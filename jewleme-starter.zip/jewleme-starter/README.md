# Jewleme Starter Project

Production-ready starter architecture for:
- React frontend
- Node.js backend
- MySQL
- Kubernetes
- GitHub Actions CI/CD
- Autoscaling (HPA)

## Run Frontend

```bash
cd frontend
npm install
npm run dev
```

## Run Backend

```bash
cd backend
npm install
npm run dev
```

## Deploy to Kubernetes

```bash
kubectl apply -f k8s/
```
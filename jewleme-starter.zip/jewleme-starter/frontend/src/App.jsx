import { useState } from 'react'
import axios from 'axios'

export default function App() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const login = async () => {
    try {
      const res = await axios.post('/api/login', {
        email,
        password
      })

      localStorage.setItem('token', res.data.token)

      alert('Login Success')
    } catch (e) {
      alert('Login Failed')
    }
  }

  return (
    <div style={{padding: '50px', fontFamily: 'Arial'}}>
      <h1>Jewleme</h1>

      <input
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
      />

      <br /><br />

      <input
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />

      <br /><br />

      <button onClick={login}>
        Login
      </button>
    </div>
  )
}